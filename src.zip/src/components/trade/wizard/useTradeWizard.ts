import { useTradeWizardContext } from "./TradeWizardContext";

export const useTradeWizard = () => useTradeWizardContext();
